<?php

namespace EspeceBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class EspeceBundle extends Bundle
{
}
