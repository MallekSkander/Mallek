<?php

namespace EvenementBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class EvenementBundle extends Bundle
{
}
